import { useState, useEffect } from 'react';
import { 
  Box, Typography, Paper, Grid, CircularProgress, Button, Divider,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Chip, TextField,
  TablePagination, IconButton, Tooltip, Dialog, DialogTitle, DialogContent, 
  DialogContentText, DialogActions, Stack
} from '@mui/material';
import { supabase } from '../supabase'; 
import ThermostatIcon from '@mui/icons-material/Thermostat';
import OpacityIcon from '@mui/icons-material/Opacity';
import CloudIcon from '@mui/icons-material/Cloud';
import SaveIcon from '@mui/icons-material/Save';
import HistoryIcon from '@mui/icons-material/History';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import { Download, Delete, WarningAmber, Refresh } from '@mui/icons-material'; 
import toast from 'react-hot-toast'; 

export default function ValidasiSensor({ userRole }) {
  const [sensorData, setSensorData] = useState(null);
  const [riwayat, setRiwayat] = useState([]);
  const [isSaving, setIsSaving] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false); 
  const [lokasiInput, setLokasiInput] = useState('');

  // --- State Pagination ---
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);

  // --- State Hapus ---
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [selectedId, setSelectedId] = useState(null);

  // --- AUTO DETECT ROLE ---
  // Mengecek apakah prop dikirim sebagai 'Admin', ATAU mendeteksi dari URL path browser
  const isAdmin = userRole === 'Admin' || window.location.pathname.includes('/admin');

  useEffect(() => {
    fetchLatestData();
    fetchRiwayat();

    const sensorSubscription = supabase
      .channel('realtime-sensor')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'sensor_validasi' }, (payload) => {
        setSensorData(payload.new);
      })
      .subscribe();

    return () => {
      supabase.removeChannel(sensorSubscription);
    };
  }, []);

  const fetchLatestData = async () => {
    const { data, error } = await supabase
      .from('sensor_validasi')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    if (!error && data) {
      setSensorData(data);
    }
  };

  const fetchRiwayat = async () => {
    const { data, error } = await supabase
      .from('riwayat_validasi')
      .select('*')
      .order('waktu_rekam', { ascending: false });

    if (!error && data) {
      setRiwayat(data);
    }
  };

  // --- FUNGSI MANUAL RELOAD DATA ---
  const handleManualRefresh = async () => {
    setIsRefreshing(true);
    const refreshToast = toast.loading('Memperbarui data...');
    try {
      await fetchLatestData();
      await fetchRiwayat();
      toast.success('Data berhasil diperbarui!', { id: refreshToast });
    } catch (error) {
      toast.error('Gagal memperbarui data.', { id: refreshToast });
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleRekamValidasi = async () => {
    if (!sensorData) return;

    if (!lokasiInput.trim()) {
      toast.error('Silakan isi nama lokasi/pasar terlebih dahulu!', {
        style: { border: '2px solid #d32f2f', padding: '16px', color: '#d32f2f', fontWeight: 'bold' }
      });
      return;
    }

    setIsSaving(true);
    const loadingToast = toast.loading('Menghubungkan ke database & menyimpan data...');

    try {
      const { error } = await supabase.from('riwayat_validasi').insert([{
        suhu: sensorData.suhu,
        kelembapan: sensorData.kelembapan,
        kadar_amonia: sensorData.kadar_amonia,
        status_ikan: sensorData.status_ikan,
        lokasi_alamat: lokasiInput 
      }]);

      if (error) throw error;

      toast.success(`Sukses merekam validasi di ${lokasiInput}!`, { id: loadingToast });
      setLokasiInput(''); 
      fetchRiwayat(); 
    } catch (error) {
      toast.error('Gagal merekam data.', { id: loadingToast });
    } finally {
      setIsSaving(false);
    }
  };

  // --- FUNGSI PAGINATION ---
  const handleChangePage = (event, newPage) => setPage(newPage);
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const paginatedRiwayat = rowsPerPage > 0 
    ? riwayat.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage) 
    : riwayat;

  // --- FUNGSI EXPORT CSV ---
  const handleExportCSV = () => {
    if (paginatedRiwayat.length === 0) {
      toast.error('Tidak ada data di halaman ini untuk diekspor.');
      return;
    }

    const headers = ['Waktu Rekam', 'Lokasi/Pasar', 'Suhu (°C)', 'Kelembapan (%)', 'Kadar Amonia (PPM)', 'Status Akhir'];
    
    const csvRows = paginatedRiwayat.map(row => {
      const escapeStr = (str) => `"${String(str || '').replace(/"/g, '""')}"`;
      return [
        escapeStr(new Date(row.waktu_rekam).toLocaleString('id-ID')),
        escapeStr(row.lokasi_alamat || '-'),
        row.suhu,
        row.kelembapan,
        row.kadar_amonia,
        escapeStr(row.status_ikan)
      ].join(',');
    });

    const csvString = [headers.join(','), ...csvRows].join('\n');
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.href = url;
    link.download = `Riwayat_Validasi_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    toast.success('Berhasil mengekspor data ke CSV!');
  };

  // --- FUNGSI HAPUS (DILINDUNGI KHUSUS ADMIN) ---
  const handleOpenDelete = (id) => {
    if (!isAdmin) {
      toast.error('Akses ditolak: Hanya Admin yang dapat menghapus data.');
      return; 
    }
    setSelectedId(id);
    setOpenDeleteDialog(true);
  };

  const handleCloseDelete = () => {
    setOpenDeleteDialog(false);
    setSelectedId(null);
  };

  const confirmDelete = async () => {
    setOpenDeleteDialog(false);
    if (selectedId && isAdmin) {
      const deleteToast = toast.loading('Menghapus riwayat...');
      const { error } = await supabase.from('riwayat_validasi').delete().eq('id', selectedId);
      
      if (!error) {
        toast.success('Riwayat berhasil dihapus!', { id: deleteToast });
        fetchRiwayat();
      } else {
        toast.error('Gagal menghapus riwayat.', { id: deleteToast });
      }
      setSelectedId(null);
    }
  };

  // --- GAYA UI ---
  const softShadow = '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)';
  const tableHeaderBg = '#1e293b';

  if (!sensorData) {
    return (
      <Paper elevation={0} sx={{ p: 4, textAlign: 'center', borderRadius: 4, boxShadow: softShadow }}>
        <CircularProgress size={40} sx={{ mb: 2 }} />
        <Typography variant="body1" color="text.secondary">
          Menunggu koneksi dari alat sensor validasi di lapangan...
        </Typography>
      </Paper>
    );
  }

  let statusColor = '#10b981'; // green modern
  if (sensorData.status_ikan === 'KRG SEGAR') statusColor = '#f59e0b'; // amber
  if (sensorData.status_ikan === 'BUSUK!') statusColor = '#ef4444'; // red

  return (
    <Box>
      {/* ========================================== */}
      {/* BAGIAN 1: LIVE MONITORING & INPUT LOKASI */}
      {/* ========================================== */}
      <Paper elevation={0} sx={{ p: 4, borderRadius: 4, bgcolor: '#ffffff', mb: 4, boxShadow: softShadow }}>
        <Typography variant="h6" fontWeight="800" color="#0f172a" sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
          Live Monitor Box Validasi IoT
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
          Pembaruan Terakhir: <b style={{ color: '#3b82f6' }}>{new Date(sensorData.created_at).toLocaleTimeString('id-ID')}</b>
        </Typography>

        <Box sx={{ p: 3, bgcolor: '#f8fafc', borderRadius: 3, border: '1px solid #e2e8f0', mb: 4 }}>
          <Grid container spacing={2} alignItems="stretch">
            {/* Input Field */}
            <Grid item xs={12} md={6} lg={7}>
              <TextField
                fullWidth label="Lokasi Tempat Validasi" placeholder="Contoh: Pasar Karombasan"
                variant="outlined" size="small"
                value={lokasiInput} onChange={(e) => setLokasiInput(e.target.value)}
                InputProps={{ startAdornment: <LocationOnIcon color="action" sx={{ mr: 1, color: '#64748b' }} /> }}
                sx={{ bgcolor: 'white', '& .MuiOutlinedInput-root': { borderRadius: 2 }, height: '100%', justifyContent: 'center' }}
              />
            </Grid>
            {/* Tombol Rekam Hasil */}
            <Grid item xs={12} sm={8} md={4} lg={3}>
              <Button 
                fullWidth variant="contained" color="primary" disableElevation
                startIcon={<SaveIcon />} onClick={handleRekamValidasi} disabled={isSaving}
                sx={{ borderRadius: 2, fontWeight: 'bold', py: 1.1, height: '100%', backgroundColor: '#3b82f6', '&:hover': { backgroundColor: '#2563eb' } }}
              >
                {isSaving ? 'Menyimpan...' : 'Rekam Hasil'}
              </Button>
            </Grid>
            {/* Tombol Reload Data */}
            <Grid item xs={12} sm={4} md={2} lg={2}>
              <Tooltip title="Muat ulang data terbaru tanpa merefresh halaman">
                <Button 
                  fullWidth variant="outlined" color="inherit" disableElevation
                  startIcon={<Refresh />} onClick={handleManualRefresh} disabled={isRefreshing}
                  sx={{ borderRadius: 2, fontWeight: 'bold', py: 1.1, height: '100%', color: '#475569', borderColor: '#cbd5e1', '&:hover': { backgroundColor: '#f1f5f9', borderColor: '#94a3b8' } }}
                >
                  Reload
                </Button>
              </Tooltip>
            </Grid>
          </Grid>
        </Box>

        <Grid container spacing={3}>
          <Grid item xs={12} md={4}>
            <Box sx={{ p: 2.5, bgcolor: '#fff7ed', borderRadius: 3, display: 'flex', alignItems: 'center', border: '1px solid #ffedd5' }}>
              <ThermostatIcon sx={{ fontSize: 48, color: '#f97316', mr: 2 }} />
              <Box>
                <Typography variant="caption" color="text.secondary" fontWeight="bold">Suhu Ruang Boks</Typography>
                <Typography variant="h5" fontWeight="900" color="#431407">{sensorData.suhu}°C</Typography>
              </Box>
            </Box>
          </Grid>

          <Grid item xs={12} md={4}>
            <Box sx={{ p: 2.5, bgcolor: '#eff6ff', borderRadius: 3, display: 'flex', alignItems: 'center', border: '1px solid #dbeafe' }}>
              <OpacityIcon sx={{ fontSize: 48, color: '#3b82f6', mr: 2 }} />
              <Box>
                <Typography variant="caption" color="text.secondary" fontWeight="bold">Kelembapan Udara</Typography>
                <Typography variant="h5" fontWeight="900" color="#1e3a8a">{sensorData.kelembapan}%</Typography>
              </Box>
            </Box>
          </Grid>

          <Grid item xs={12} md={4}>
            <Box sx={{ p: 2.5, bgcolor: '#fdf4ff', borderRadius: 3, display: 'flex', alignItems: 'center', border: '1px solid #fae8ff' }}>
              <CloudIcon sx={{ fontSize: 48, color: '#d946ef', mr: 2 }} />
              <Box>
                <Typography variant="caption" color="text.secondary" fontWeight="bold">Kadar Amonia (MQ-137)</Typography>
                <Typography variant="h5" fontWeight="900" color="#701a75">{sensorData.kadar_amonia} PPM</Typography>
              </Box>
            </Box>
          </Grid>
        </Grid>

        <Box sx={{ mt: 4, p: 3, bgcolor: statusColor, borderRadius: 3, textAlign: 'center', color: 'white', boxShadow: `0 10px 15px -3px ${statusColor}40` }}>
          <Typography variant="overline" sx={{ letterSpacing: 2, fontWeight: 'bold' }}>KESIMPULAN VALIDASI SENSOR</Typography>
          <Typography variant="h3" fontWeight="900" sx={{ mt: 0.5 }}>{sensorData.status_ikan}</Typography>
        </Box>
      </Paper>

      {/* ========================================== */}
      {/* BAGIAN 2: RIWAYAT VALIDASI */}
      {/* ========================================== */}
      <Paper elevation={0} sx={{ p: 4, borderRadius: 4, bgcolor: '#ffffff', boxShadow: softShadow }}>
        <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 2 }}>
          <Typography variant="h6" fontWeight="800" sx={{ display: 'flex', alignItems: 'center', color: '#0f172a' }}>
            <HistoryIcon sx={{ mr: 1, color: '#3b82f6' }} /> Riwayat Perekaman Validasi
          </Typography>
          <Button 
            variant="contained" startIcon={<Download />} onClick={handleExportCSV} disableElevation
            sx={{ backgroundColor: '#10b981', '&:hover': { backgroundColor: '#059669' }, borderRadius: 2, fontWeight: 'bold', textTransform: 'none' }}
          >
            Export
          </Button>
        </Stack>
        <Divider sx={{ mb: 3 }} />

        <Paper elevation={0} sx={{ border: '1px solid #e2e8f0', borderRadius: 2, overflow: 'hidden' }}>
          <TableContainer>
            <Table size="small">
              <TableHead sx={{ bgcolor: tableHeaderBg }}>
                <TableRow>
                  <TableCell sx={{ color: 'white', fontWeight: '600' }}>Waktu Rekam</TableCell>
                  <TableCell sx={{ color: 'white', fontWeight: '600' }}>Lokasi / Pasar</TableCell>
                  <TableCell sx={{ color: 'white', fontWeight: '600' }}>Suhu</TableCell>
                  <TableCell sx={{ color: 'white', fontWeight: '600' }}>Kelembapan</TableCell>
                  <TableCell sx={{ color: 'white', fontWeight: '600' }}>Kadar Gas</TableCell>
                  <TableCell sx={{ color: 'white', fontWeight: '600', textAlign: 'center' }}>Status Akhir</TableCell>
                  {/* Kolom Aksi Hanya untuk Admin */}
                  {isAdmin && (
                    <TableCell sx={{ color: 'white', fontWeight: '600', textAlign: 'center' }}>Aksi</TableCell>
                  )}
                </TableRow>
              </TableHead>
              <TableBody>
                {paginatedRiwayat.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={isAdmin ? 7 : 6} align="center" sx={{ py: 6, color: '#64748b' }}>
                      Belum ada riwayat validasi yang direkam.
                    </TableCell>
                  </TableRow>
                ) : (
                  paginatedRiwayat.map((row) => {
                    let badgeColor = 'success';
                    if (row.status_ikan === 'KRG SEGAR') badgeColor = 'warning';
                    if (row.status_ikan === 'BUSUK!') badgeColor = 'error';

                    return (
                      <TableRow key={row.id} sx={{ transition: '0.2s', '&:hover': { backgroundColor: '#f8fafc' } }}>
                        <TableCell sx={{ color: '#475569', fontWeight: 500 }}>{new Date(row.waktu_rekam).toLocaleString('id-ID')}</TableCell>
                        <TableCell sx={{ fontWeight: '600', color: '#334155' }}>{row.lokasi_alamat || '-'}</TableCell>
                        <TableCell sx={{ color: '#475569' }}>{row.suhu}°C</TableCell>
                        <TableCell sx={{ color: '#475569' }}>{row.kelembapan}%</TableCell>
                        <TableCell sx={{ color: '#475569' }}>{row.kadar_amonia} PPM</TableCell>
                        <TableCell align="center">
                          <Chip label={row.status_ikan} color={badgeColor} size="small" sx={{ fontWeight: 'bold', borderRadius: 1.5 }} />
                        </TableCell>
                        {/* Tombol Hapus Hanya Muncul Jika URL adalah Admin */}
                        {isAdmin && (
                          <TableCell align="center">
                            <Tooltip title="Hapus Data">
                              <IconButton size="small" color="error" onClick={() => handleOpenDelete(row.id)} sx={{ backgroundColor: '#fef2f2', '&:hover': { backgroundColor: '#fee2e2' } }}>
                                <Delete fontSize="small" />
                              </IconButton>
                            </Tooltip>
                          </TableCell>
                        )}
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            rowsPerPageOptions={[5, 10, 25, 50, { label: 'Semua', value: -1 }]}
            component="div"
            count={riwayat.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
            labelRowsPerPage="Baris per halaman:"
            labelDisplayedRows={({ from, to, count }) => `${from}-${to} dari ${count !== -1 ? count : `lebih dari ${to}`}`}
            sx={{ borderTop: '1px solid #f1f5f9' }}
          />
        </Paper>
      </Paper>

      {/* --- DIALOG KONFIRMASI HAPUS (Khusus Admin) --- */}
      <Dialog
        open={openDeleteDialog}
        onClose={handleCloseDelete}
        PaperProps={{ style: { borderRadius: 16, padding: '12px' } }}
      >
        <DialogTitle sx={{ display: 'flex', alignItems: 'center', color: '#ef4444', fontWeight: 'bold' }}>
          <WarningAmber sx={{ mr: 1 }} /> Konfirmasi Penghapusan
        </DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ color: '#475569' }}>
            Apakah Anda yakin ingin menghapus data riwayat validasi ini? 
            Data yang dihapus <b style={{ color: '#0f172a' }}>tidak dapat dikembalikan</b>.
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ pb: 2, pr: 2 }}>
          <Button onClick={handleCloseDelete} sx={{ color: '#64748b', fontWeight: 'bold', textTransform: 'none' }}>
            Batal
          </Button>
          <Button onClick={confirmDelete} color="error" variant="contained" disableElevation autoFocus sx={{ borderRadius: 2, fontWeight: 'bold', textTransform: 'none' }}>
            Ya, Hapus
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}