import { useState } from 'react';
import { Container, Paper, Typography, TextField, Button, Box, Alert, InputAdornment, Avatar } from '@mui/material';
import { useNavigate, Link } from 'react-router-dom';
import { supabase } from '../supabase';
import BadgeIcon from '@mui/icons-material/Badge';
import LockIcon from '@mui/icons-material/Lock';
import PhishingIcon from '@mui/icons-material/Phishing'; // Ikon tema ikan

export default function Login() {
  const navigate = useNavigate();
  const [nip, setNip] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      // Cari user berdasarkan NIP dan Password di tabel users
      const { data: user, error: fetchError } = await supabase
        .from('users')
        .select('*')
        .eq('nip', nip)
        .eq('password', password)
        .single(); // Ambil 1 data yang cocok

      if (fetchError || !user) {
        throw new Error('NIP atau Password salah!');
      }

      // Jika berhasil, simpan sesi user di LocalStorage browser
      localStorage.setItem('user', JSON.stringify(user));

      // Arahkan berdasarkan Role
      if (user.role === 'Admin') {
        navigate('/admin/dashboard');
      } else if (user.role === 'Dinas') {
        navigate('/dinas/dashboard');
      }

    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box 
      sx={{ 
        minHeight: '100vh', 
        display: 'flex', 
        alignItems: 'center', 
        background: 'linear-gradient(135deg, #1e3c72 0%, #2a5298 100%)', // Gradien biru laut
        padding: 2
      }}
    >
      <Container maxWidth="xs">
        <Paper elevation={12} sx={{ p: 4, borderRadius: 4, backdropFilter: 'blur(10px)' }}>
          <Box display="flex" flexDirection="column" alignItems="center" mb={3}>
            <Avatar sx={{ m: 1, bgcolor: '#1976d2', width: 56, height: 56 }}>
              <PhishingIcon fontSize="large" />
            </Avatar>
            <Typography variant="h5" fontWeight="900" color="#1e3c72" gutterBottom>
              PORTAL LOGIN
            </Typography>
            <Typography variant="body2" align="center" color="text.secondary">
              Sistem Klasifikasi Kualitas Ikan AI
            </Typography>
          </Box>

          {error && <Alert severity="error" sx={{ mb: 3, borderRadius: 2 }}>{error}</Alert>}

          <form onSubmit={handleLogin}>
            <TextField
              fullWidth label="Nomor Induk Pegawai (NIP)" variant="outlined" margin="normal" required
              value={nip} onChange={(e) => setNip(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <BadgeIcon color="action" />
                  </InputAdornment>
                ),
              }}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: 3 } }}
            />
            <TextField
              fullWidth label="Password" type="password" variant="outlined" margin="normal" required
              value={password} onChange={(e) => setPassword(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <LockIcon color="action" />
                  </InputAdornment>
                ),
              }}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: 3 } }}
            />

            <Button 
              type="submit" fullWidth variant="contained" size="large" 
              disabled={loading}
              sx={{ 
                mt: 4, mb: 3, py: 1.5, borderRadius: 3, 
                fontWeight: 'bold', fontSize: '1.1rem',
                background: 'linear-gradient(45deg, #1976d2 30%, #21CBF3 90%)',
                boxShadow: '0 3px 5px 2px rgba(33, 203, 243, .3)',
                transition: 'transform 0.2s',
                '&:hover': { transform: 'scale(1.02)' }
              }}
            >
              {loading ? 'MEMVERIFIKASI...' : 'MASUK SEKARANG'}
            </Button>

            <Box textAlign="center">
              <Typography variant="body2" color="text.secondary">
                Belum memiliki akses?{' '}
                <Link to="/register" style={{ textDecoration: 'none', color: '#1976d2', fontWeight: 'bold' }}>
                  Daftar di sini
                </Link>
              </Typography>
            </Box>
          </form>
        </Paper>
      </Container>
    </Box>
  );
}