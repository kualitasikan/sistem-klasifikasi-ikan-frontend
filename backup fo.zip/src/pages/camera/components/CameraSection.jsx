import { Box, Stack, Button, IconButton, Typography, CircularProgress, Chip } from '@mui/material';
import PhotoCamera from '@mui/icons-material/PhotoCamera';
import CloseIcon from '@mui/icons-material/Close';
import FlipCameraIosIcon from '@mui/icons-material/FlipCameraIos'; // Icon baru untuk tombol putar kamera

export default function CameraSection({
  isCameraOpen, videoRef, ambilFotoDariStream, matikanKamera, preview, 
  result, confidence, layakKonsumsi, nyalakanKamera, handleImageChange, 
  handleClassify, isClassifying, facingMode, gantiKamera
}) {
  
  // Tentukan apakah video perlu di-mirror (hanya untuk kamera depan)
  const isMirrored = facingMode === 'user';

  return (
    <>
      {/* VIEW BOX STREAM KAMERA */}
      {isCameraOpen && (
        <Box sx={{ position: 'relative', mb: 3, bgcolor: '#000', borderRadius: '15px', overflow: 'hidden' }}>
          <video 
            ref={videoRef} 
            autoPlay 
            playsInline 
            style={{ 
              width: '100%', 
              maxHeight: '400px', 
              objectFit: 'cover',
              transform: isMirrored ? 'scaleX(-1)' : 'none' // Efek Cermin Otomatis via CSS
            }} 
          />
          <Stack direction="row" spacing={2} sx={{ position: 'absolute', bottom: 20, left: '50%', transform: 'translateX(-50%)' }}>
            <Button variant="contained" color="primary" onClick={ambilFotoDariStream} sx={{ borderRadius: 5, px: 3, fontWeight: 'bold' }}>
              Ambil Foto
            </Button>
            
            {/* TOMBOL FLIP KAMERA */}
            <IconButton onClick={gantiKamera} sx={{ bgcolor: 'secondary.main', color: '#fff', '&:hover': { bgcolor: 'secondary.dark' } }}>
              <FlipCameraIosIcon />
            </IconButton>

            <IconButton onClick={matikanKamera} sx={{ bgcolor: 'error.main', color: '#fff', '&:hover': { bgcolor: 'error.dark' } }}>
              <CloseIcon />
            </IconButton>
          </Stack>
        </Box>
      )}

      {/* BOX PREVIEW GAMBAR + BADGE HASIL AI */}
      {preview && !isCameraOpen && (
        <Box sx={{ position: 'relative', mb: 3 }}>
          <img src={preview} alt="Preview" style={{ width: '100%', maxHeight: '400px', borderRadius: '15px', objectFit: 'cover' }} />
          {result && (
            <Chip 
              label={`${result} (${confidence || '0%'})`} 
              color={layakKonsumsi ? 'success' : 'error'}
              sx={{ position: 'absolute', top: 20, right: 20, fontWeight: 'bold', px: 2, py: 2.5, fontSize: '1rem' }} 
            />
          )}
        </Box>
      )}

      {/* CONTAINER VIEW AWAL KOSONG */}
      {!preview && !isCameraOpen && (
        <Box sx={{ py: 8, border: '2px dashed #b0bec5', borderRadius: 4, mb: 3, bgcolor: '#fafafa' }}>
          <PhotoCamera sx={{ fontSize: 60, color: '#b0bec5', mb: 2 }} />
          <Typography color="text.secondary">Belum ada foto objek ikan yang diambil</Typography>
        </Box>
      )}

      {/* TOMBOL AKSI UTAMA */}
      <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2} justifyContent="center">
        {/* Gunakan arrow function agar event onClick tidak masuk sebagai parameter 'mode' */}
        <Button variant="contained" color="primary" startIcon={<PhotoCamera />} onClick={() => nyalakanKamera()} disabled={isCameraOpen} sx={{ borderRadius: 3, px: 3 }}>
          Buka Kamera Langsung
        </Button>
        <Button variant="outlined" component="label" size="large" sx={{ borderRadius: 3, px: 3 }}>
          Pilih dari Galeri File
          <input hidden accept="image/*" type="file" onChange={handleImageChange} />
        </Button>
        {preview && !result && !isCameraOpen && (
          <Button variant="contained" color="success" size="large" onClick={handleClassify} disabled={isClassifying} sx={{ borderRadius: 3, px: 4 }}>
            {isClassifying ? <CircularProgress size={24} color="inherit" /> : 'Cek Kualitas Sekarang'}
          </Button>
        )}
      </Stack>
    </>
  );
}