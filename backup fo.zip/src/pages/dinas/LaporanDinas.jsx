import { useState, useEffect } from 'react';
import { 
  Paper, Typography, Table, TableBody, TableCell, 
  TableContainer, TableHead, TableRow, MenuItem, Select, Box,
  TextField, Button, Grid, InputAdornment, TablePagination
} from '@mui/material';
import { Search, FilterAlt, RestartAlt, Download } from '@mui/icons-material';
import { supabase } from '../../supabase';
import toast from 'react-hot-toast'; 

export default function LaporanDinas() {
  const [laporan, setLaporan] = useState([]);
  const [filter, setFilter] = useState({ tanggal: '', lokasi: '', status: 'Semua' });

  // --- State untuk Pagination ---
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);

  useEffect(() => {
    fetchLaporan();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter]);

  const fetchLaporan = async () => {
    let query = supabase.from('laporan').select('*').order('created_at', { ascending: false });

    if (filter.tanggal) query = query.gte('created_at', `${filter.tanggal}T00:00:00Z`).lte('created_at', `${filter.tanggal}T23:59:59Z`);
    if (filter.lokasi) query = query.ilike('lokasi_alamat', `%${filter.lokasi}%`);
    if (filter.status !== 'Semua') query = query.eq('status_penanganan', filter.status);

    const { data, error } = await query;
    if (!error) {
      setLaporan(data);
      setPage(0); // Reset ke halaman pertama jika filter berubah
    } else {
      toast.error('Gagal memuat data laporan terbaru.');
    }
  };

  const handleUpdateStatus = async (id, newStatus) => {
    const updateToast = toast.loading('Memperbarui status...'); 

    const { error } = await supabase.from('laporan').update({ status_penanganan: newStatus }).eq('id_laporan', id);
    
    if (!error) {
      fetchLaporan();
      toast.success(`Status diperbarui menjadi: ${newStatus}`, { id: updateToast }); 
    } else {
      toast.error('Terjadi kesalahan saat memperbarui status.', { id: updateToast }); 
    }
  };

  const getStatusColor = (status) => {
    if (status === 'Selesai') return '#10b981'; // Green
    if (status === 'Diproses') return '#f59e0b'; // Amber
    return '#ef4444'; // Red
  };

  // --- FUNGSI PAGINATION ---
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const paginatedLaporan = rowsPerPage > 0 
    ? laporan.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
    : laporan;

  // --- FUNGSI EXPORT CSV ---
  const handleExportCSV = () => {
    if (paginatedLaporan.length === 0) {
      toast.error('Tidak ada data di halaman ini untuk diekspor.');
      return;
    }

    const headers = ['Waktu', 'Jenis Ikan', 'Lokasi/Alamat', 'Keterangan', 'Status Penanganan'];
    
    const csvRows = paginatedLaporan.map(row => {
      const date = new Date(row.created_at).toLocaleDateString('id-ID');
      
      const escapeString = (str) => {
        if (!str) return '""';
        const clean = String(str).replace(/"/g, '""'); 
        return `"${clean}"`; 
      };

      return [
        escapeString(date),
        escapeString(row.jenis_ikan),
        escapeString(row.lokasi_alamat),
        escapeString(row.keterangan || '-'),
        escapeString(row.status_penanganan)
      ].join(',');
    });

    const csvString = [headers.join(','), ...csvRows].join('\n');
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.href = url;
    link.download = `Tindak_Lanjut_Laporan_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    toast.success('Berhasil mengekspor data ke CSV!');
  };

  // --- DESAIN UI MODERN (Soft shadows & Custom Colors) ---
  const softShadow = '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)';
  const tableHeaderBg = '#1e293b'; // Slate 800 (Gelap modern)

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Box>
          <Typography variant="h5" fontWeight="800" sx={{ color: '#0f172a' }} gutterBottom>
            Tindak Lanjut Laporan (Dinas)
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Pilih laporan dan perbarui status penanganannya agar masyarakat mengetahui prosesnya.
          </Typography>
        </Box>
      </Box>
      
      {/* Bagian Filter */}
      <Paper elevation={0} sx={{ p: 3, mb: 4, borderRadius: 3, backgroundColor: '#ffffff', boxShadow: softShadow }}>
        <Typography variant="subtitle2" fontWeight="700" sx={{ mb: 2.5, display: 'flex', alignItems: 'center', color: '#3b82f6' }}>
          <FilterAlt fontSize="small" sx={{ mr: 1 }} /> Filter & Pencarian Laporan
        </Typography>
        
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} sm={6} md={3}>
            <TextField label="Tanggal Laporan" type="date" size="small" InputLabelProps={{ shrink: true }} fullWidth
              value={filter.tanggal} onChange={(e) => setFilter({ ...filter, tanggal: e.target.value })} 
            />
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <TextField label="Cari Lokasi / Pasar" placeholder="Ketik lokasi..." size="small" fullWidth
              value={filter.lokasi} onChange={(e) => setFilter({ ...filter, lokasi: e.target.value })}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Search fontSize="small" />
                  </InputAdornment>
                ),
              }}
            />
          </Grid>
          <Grid item xs={12} sm={4} md={2}>
            <TextField select label="Status" size="small" fullWidth
              value={filter.status} onChange={(e) => setFilter({ ...filter, status: e.target.value })}
            >
              <MenuItem value="Semua">Semua Status</MenuItem>
              <MenuItem value="Menunggu">Menunggu</MenuItem>
              <MenuItem value="Diproses">Diproses</MenuItem>
              <MenuItem value="Selesai">Selesai</MenuItem>
            </TextField>
          </Grid>
          <Grid item xs={12} sm={4} md={2}>
            <Button 
              variant="outlined" 
              color="inherit" 
              fullWidth 
              startIcon={<RestartAlt />}
              onClick={() => setFilter({ tanggal: '', lokasi: '', status: 'Semua' })}
              sx={{ height: '40px', borderRadius: 2, fontWeight: 'bold' }}
            >
              Reset
            </Button>
          </Grid>
          <Grid item xs={12} sm={4} md={2}>
            <Button 
              variant="contained" 
              fullWidth 
              startIcon={<Download />}
              onClick={handleExportCSV}
              sx={{ height: '40px', borderRadius: 2, fontWeight: 'bold', backgroundColor: '#10b981', '&:hover': { backgroundColor: '#059669' }, boxShadow: 'none' }}
            >
              Export
            </Button>
          </Grid>
        </Grid>
      </Paper>

      {/* Bagian Tabel */}
      <Paper elevation={0} sx={{ borderRadius: 3, overflow: 'hidden', boxShadow: softShadow, backgroundColor: '#ffffff' }}>
        <TableContainer>
          <Table sx={{ minWidth: 650 }}>
            <TableHead sx={{ backgroundColor: tableHeaderBg }}>
              <TableRow>
                <TableCell sx={{ color: 'white', fontWeight: '600' }}>Waktu</TableCell>
                <TableCell sx={{ color: 'white', fontWeight: '600' }}>Ikan</TableCell>
                <TableCell sx={{ color: 'white', fontWeight: '600' }}>Lokasi</TableCell>
                <TableCell sx={{ color: 'white', fontWeight: '600', minWidth: 200 }}>Keterangan Warga</TableCell>
                <TableCell sx={{ color: 'white', fontWeight: '600' }}>Update Status</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {paginatedLaporan.map((row) => (
                <TableRow key={row.id_laporan} sx={{ transition: '0.2s', '&:hover': { backgroundColor: '#f8fafc' }, '&:last-child td, &:last-child th': { border: 0 } }}>
                  <TableCell sx={{ color: '#475569', fontWeight: 500 }}>{new Date(row.created_at).toLocaleDateString('id-ID')}</TableCell>
                  <TableCell>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                      <img src={row.foto_ikan} alt="Ikan" style={{ width: 50, height: 50, borderRadius: 8, objectFit: 'cover', border: '1px solid #e2e8f0' }} />
                      <Typography variant="body2" fontWeight="600" color="#334155">{row.jenis_ikan}</Typography>
                    </Box>
                  </TableCell>
                  <TableCell sx={{ color: '#475569' }}>{row.lokasi_alamat}</TableCell>
                  <TableCell>
                    <Typography variant="body2" color="text.secondary">
                      {row.keterangan ? row.keterangan : '-'}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Select
                      value={row.status_penanganan}
                      onChange={(e) => handleUpdateStatus(row.id_laporan, e.target.value)}
                      size="small"
                      sx={{ 
                        minWidth: 140, 
                        backgroundColor: 'white',
                        color: getStatusColor(row.status_penanganan),
                        fontWeight: 'bold',
                        borderRadius: 1.5,
                        '& .MuiOutlinedInput-notchedOutline': { borderColor: getStatusColor(row.status_penanganan), opacity: 0.5 },
                        '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: getStatusColor(row.status_penanganan), opacity: 1 },
                      }}
                    >
                      <MenuItem value="Menunggu" sx={{ color: '#ef4444', fontWeight: 'bold' }}>Menunggu</MenuItem>
                      <MenuItem value="Diproses" sx={{ color: '#f59e0b', fontWeight: 'bold' }}>Diproses</MenuItem>
                      <MenuItem value="Selesai" sx={{ color: '#10b981', fontWeight: 'bold' }}>Selesai</MenuItem>
                    </Select>
                  </TableCell>
                </TableRow>
              ))}
              {laporan.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} align="center" sx={{ py: 6, color: '#64748b' }}>
                    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1 }}>
                      <FilterAlt sx={{ fontSize: 40, color: '#cbd5e1' }} />
                      <Typography variant="body1">Tidak ada data laporan yang cocok dengan filter.</Typography>
                    </Box>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>

        <TablePagination
          rowsPerPageOptions={[5, 10, 25, 50, { label: 'Semua', value: -1 }]}
          component="div"
          count={laporan.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
          labelRowsPerPage="Baris per halaman:"
          labelDisplayedRows={({ from, to, count }) => `${from}-${to} dari ${count !== -1 ? count : `lebih dari ${to}`}`}
          sx={{ borderTop: '1px solid #f1f5f9' }}
        />
      </Paper>
    </Box>
  );
}